package edu.uwm.android.diabetes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ExerciseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);
    }
}
